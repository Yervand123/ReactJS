import { useState } from "react";
import "./Timer.css";

let id = null;
export default function Timer() {
    const [time,setTime] = useState(0);
    const [value,setValue] = useState("");
    const [disableBtn,setDisableBtn] = useState(false);

    const onChangeInput = (e) => {
     
        if(!isNaN(e.target.value)){
            setValue(e.target.value)
        }else{
            alert("Please,input only number");
        }
        
    }
    const startTimerFunction = () => {
       if(!id){
        id = setInterval(()=>{
            setTime(time => {
                if(time === 0){
                    clearInterval(id);
                    id = null;
                    return 0;
                }
                return time - 1;
            })
        },1000);
       }
    }
    const setTimeFunction = () => {
        setTime(+value);
        setValue("");
    }

    const StopTime = () => {
         clearInterval(id);
    } 
    const restart = () =>{
      setTime(0);
    }
        
        
  return (
    <div className="container">
      <div className="div-container">
        <div className="inner-div">
          <span className="spanTimer">Timer: {time}</span>
          <button className="btn" onClick={startTimerFunction} disabled = {disableBtn}>Start Timer</button>
          <div className="buttons">
          <button onClick={StopTime}>StopTime</button>
          <button onClick={restart}>continue</button>
          </div>
        </div>
        <div className="inner-div">
          <input className="input" value={value} onChange={onChangeInput}/>
          <button className="btn" onClick={setTimeFunction}>Set Time</button>
         
        </div>
      </div>
    </div>
     );



  }
